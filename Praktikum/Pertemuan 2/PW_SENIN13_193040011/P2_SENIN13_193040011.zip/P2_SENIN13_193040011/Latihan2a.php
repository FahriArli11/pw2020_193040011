<?php
    for ($i = 1; $i <= 3; $i++) {
        for ($p = 1; $p <= 3; $p++) {
            echo "Ini perulangan ke ($i,$p) <br>";
        }
    }
?>